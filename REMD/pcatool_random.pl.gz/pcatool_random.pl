#!/usr/bin/perl

for(my $i = 0; $i <= 1000; $i++){

open(fh, "ilmode_in.txt") or die "Could not read file";
while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
   $cmd = "pcatool $l[0]_refPDB_traj.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]_ilmode --rmsd_log --remove_anchors --random_model > $l[0]_ilmode.log; \n";
 #   $cmd = "pcatool $l[0]_rcd.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]_ilmode --rmsd_log --remove_anchors --random_model > $l[0]_ilmode.log; \n";
   #  $cmd = "pcatool $l[0].loop.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0] --rmsd_log --remove_anchors --random_model > $l[0].log;\n";

    print $cmd;
    system($cmd);    
  
}    
close(fh);

$cmd = "compare.pl; table0.pl > random_$i.txt\n";
print $cmd;
system($cmd);    

}
