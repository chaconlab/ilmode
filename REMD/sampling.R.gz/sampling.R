#Libraries
library(ggplot2)
library(ggpubr)
library(dplyr)
library(stringr)
library(reshape2)
library(cowplot)
library(ggpmisc)
library(hrbrthemes)
library(RColorBrewer)
library(gridExtra)
library(data.table)

setwd("/home/pablo/ilmode/wu/MD_ok")




pdbs = c("2eaq", "5w0g", "2ns0")

pdbs = c("2eaq", "5w0g", "2ns0","4dpb","5nod","6elm","3bv8","5e9p","4bpf","6fmb","5k2l","3k3v","3fdr", "4qy7","3dkm")
limitesX = c(5,5,5, 4,4,4, 4,7,6, 6,5,8, 6,5, 12)
limitesY = c(-1800,-1700,-1700, -2500,-1400,-1600, -1000,-1700,-1200,
             -1200,-600,-1000, -1500,-1600,-1200)


#df <- my_data[-c(1:3), ]
#rows = nrow(df)-2
#my_data<- df[-c(rows:nrow(df)), ]


  test=3
  file = sprintf("s_%s.txt", pdbs[test])
  MD <- read.table(file)
  file = sprintf("s2_%s.txt", pdbs[test])
  NMA <- read.table(file)
  file = sprintf("s3_%s.txt", pdbs[test])
  RCD <- read.table(file)
  file = sprintf("s4_%s.txt", pdbs[test])
  NMA2 <- read.table(file)
  print(file)
  AP <- subset(NMA, V1<=1)
  
  best10 <- top_n(NMA, -10, V2)
  AMin <- subset(best10, V7<=min(V7))
  best10 <- top_n(RCD, -10, V2)
  AMin2 <- subset(best10, V7<=min(V7))
  
  
  
  
  
  
bf<-ggplot() +
  geom_point(aes(x = MD$V7,  y = MD$V2), color="blue",size=0.1,alpha=0.5) +
  geom_point(aes(x = NMA$V7,  y = NMA$V2), color="orange",size=0.1, alpha=0.2) +
  geom_point(aes(x = RCD$V7,  y = RCD$V2), color="green",size=0.1, alpha=0.2) +
  #geom_point(aes(x = NMA2$V7,  y = NMA2$V2), color="red",size=0.1, alpha=0.2) +
  
  geom_point(aes(x = AP$V7,  y = AP$V2), color="darkblue",size=3, shape=17) +
  geom_point(aes(x = AMin$V7,  y = AMin$V2), color="darkorange",size=3, shape=15) +
  geom_point(aes(x = AMin2$V7,  y = AMin2$V2), color="green",size=3, shape=19) +
  theme_bw() +
  scale_x_continuous(expand = c(0, 0), limits = c(0,limitesX[test])) + 
  scale_y_continuous(expand = c(0, 0), limits = c( NA ,limitesY[test])) + 
  
  theme(plot.title = element_text(size = 32), 
        axis.text.x = element_text(size = 20, face = "bold"), 
        axis.title.x=element_blank(),  axis.title.y=element_blank())  +
ggtitle(pdbs[test])

print(bf)


gc()



  pl2 <- lapply(1:length(pdbs), function(i){
    file = sprintf("s_%s.txt", pdbs[i])
    MD <- read.table(file)
    file = sprintf("s2_%s.txt", pdbs[i])
    NMA <- read.table(file)
    file = sprintf("s3_%s.txt", pdbs[i])
    RCD <- read.table(file)
    file = sprintf("s4_%s.txt", pdbs[i])
    NMA2 <- read.table(file)
    
    

    AP <- subset(NMA, V1<=1)
    AP2 <- subset(NMA2, V1<=1)
    
    #AMin <- subset(NMA, V2<=min(V2))
    #AMin2 <- subset(RCD, V2<=min(V2))

    RMin <- subset(MD, V7<=min(V7))
    RMin2 <- subset(NMA, V7<=min(V7))
    RMin3 <- subset(RCD, V7<=min(V7))
    RMin4 <- subset(NMA2, V7<=min(V7))
    
    BMin <- subset(MD, V2<=min(V2))
    BMin2 <- subset(NMA, V2<=min(V2))
    BMin3 <- subset(RCD, V2<=min(V2))
    BMin4 <- subset(NMA2, V2<=min(V2))
    
    best10 <- top_n(MD, -10, V2)
    AMin <- subset(best10, V7<=min(V7))
    
    best10 <- top_n(NMA, -10, V2)
    AMin2 <- subset(best10, V7<=min(V7))
    
    best10 <- top_n(RCD, -100, V2)
    AMin3 <- subset(best10, V7<=min(V7))
    
    best10 <- top_n(NMA2, -1000, V2)
    AMin4 <- subset(best10, V7<=min(V7))
    

    
    cat(sprintf("%s %.2f %.2f %.2f  %.2f  %.2f %.2f %.2f     %.2f  %.2f %.2f -> %10d   %.2f %.2f %.2f %.2f\n", 
                pdbs[i], RMin$V7, BMin$V7,  AMin$V7,  AP$V7, 
                         RMin2$V7, BMin2$V7,  AMin2$V7,
                         RMin3$V7, BMin3$V7, AMin3$V7, AMin3$V1,
                         RMin4$V7, BMin4$V7, AMin4$V7, AP2$V7 ))
    
    ggplot() +
      geom_point(aes(x = MD$V7,  y = MD$V2), color="blue",size=0.1,alpha=0.5) +
      geom_point(aes(x = NMA$V7,  y = NMA$V2), color="orange",size=0.1, alpha=0.2) +
      geom_point(aes(x = RCD$V7,  y = RCD$V2), color="green",size=0.1, alpha=0.2) +
     # geom_point(aes(x = NMA2$V7,  y = NMA2$V2), color="green",size=0.1, alpha=0.2) +
      
      geom_point(aes(x = AP$V7,  y = AP$V2), color="darkblue",size=5, shape=17) +
      geom_point(aes(x = AMin2$V7,  y = AMin2$V2), color="darkorange",size=5, shape=15) +
      geom_point(aes(x = AMin3$V7,  y = AMin3$V2), color="green",size=5, shape=19) +
    #  geom_point(aes(x = AMin4$V7,  y = AMin4$V2), color="darkred",size=3, shape=19) +
      
      scale_x_continuous(expand = c(0, 0), limits = c(0,limitesX[i])) + 
      scale_y_continuous(expand = c(0, 0), limits = c( NA ,limitesY[i])) + 
      
      theme_bw() +
      theme(plot.title = element_text(size = 32), 
            axis.text.x = element_text(size = 20, face = "bold"), 
            axis.title.x=element_blank(),  axis.title.y=element_blank()) + 
      
      ggtitle(pdbs[i])
    
 #   print(pl2[[i]])
    
    })
  
  

 # pl[[i]] <- bf
  



dev.off()
gridExtra::grid.arrange(grobs = pl2)
plot_grid(plotlist = pl2, labels = NULL, ncol = 3)




