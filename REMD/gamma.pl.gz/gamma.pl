#!/usr/bin/perl
 
# Manu Rueda
#
# DOT PRODUCT BETWEEN PTRAJ EIGENVECTORS
#
#
use strict;

if ( !($#ARGV == 4 || $#ARGV == 5) ) 
{
    print "USAGE: $0 <evec1> <evec2> [nvectors] [start1] [start2] [debug]\n";
    print "[start#] --> (1,2,3...,3N; 1st not-null mode number)\n";
    exit;
    print "USAGE: $0 <evec1> <evec2> [nvectors] [start1] [start2] [debug]\n";
    print "\t<evec1> --> Eigenvector set 1\n";
    print "\t<evec2> --> Eigenvector set 2\n";
    print "\t[nvectors] --> Number of vectors to take into account (=all --> all vectors)\n";
    print "\t[start1] --> Starting vector from set 1\n";
    print "\t[start2] --> Starting vector from set 2\n";
    print "Description: Computes GAMMA score (cummulative dot product) between a two eigenvector sets\n";
    print "WARNING: Both should be properly normalized! (gamma=1)\n";
}

	my $file1=$ARGV[0];
	my $file2=$ARGV[1];
 	my $nevec=$ARGV[2];
 	my $start1=$ARGV[3];
 	my $start2=$ARGV[4];
	my $debug=0;
	if( $#ARGV == 5 )
	{
	  $debug=1;
	}

        my $able1 = num_evecs($file1); # number of vectors
        my $able2 = num_evecs($file2); # number of vectors

	if($nevec eq "all")
	{
	  $nevec = $able1;
	  print "$file1 contains = $able1 vectors\n";
	  print "$file2 contains = $able2 vectors\n";
	}
	if($nevec > $able1)
	{
	  printf STDERR "Sorry, more vectors requested ($nevec) than available in $file1 ($able1)\nSetting the maximum available ($able1)!\n";
	  $nevec = $able1;
	}
	if($nevec > $able2)
	{
	  print STDERR "Sorry, more vectors requested ($nevec) than available in $file2 ($able2)\nSetting the maximum available ($able2)!\n";
	  $nevec = $able2;
	}

        # Number of evecs needed
	my $max1=$nevec+$start1-1;
	my $max2=$nevec+$start2-1;

        # Number of evecs available
        open (EVEC,"$file1") || die "Cannot open $file1\n";
        my @maxevec1=grep{/[0-9]/}(map{split / +/,$_}(map scalar <EVEC>, 1..2));
        my $able1=$maxevec1[2];
        close EVEC;
        open (EVEC,"$file2") || die "Cannot open $file2\n";
        my @maxevec2=grep{/[0-9]/}(map{split / +/,$_}(map scalar <EVEC>, 1..2));
        my $able2=$maxevec2[2];
        close EVEC;

        if ( $max1>$able1 ) 
        { 
          print STDERR "# Warning: $max1 vectors needed but there are only $able1, changing [nvectors] ($nevec) to the maximum available: "; 
          $nevec -= $max1-$able1;
          print STDERR "$nevec\n";

          # Redefining max1 & max2
	  $max1=$nevec+$start1-1;
	  $max2=$nevec+$start2-1;
        }

        if ( $max2>$able2 ) 
        { 
          print STDERR "# Warning: $max2 vectors needed but there are only $able2, changing [nvectors]($nevec) to the maximum available: "; 
          $nevec -= $max2-$able2;
          print STDERR "$nevec\n";

          # Redefining max1 & max2
	  $max1=$nevec+$start1-1;
	  $max2=$nevec+$start2-1;
        }

	my $vec1=read_evec($file1,$max1);
        my $vec2=read_evec($file2,$max2);
	
	
	
	my @gammaN;
	@gammaN = gammaN($start1,$start2,$nevec);

        my $cont=0;
        foreach(@gammaN)
        {
	  $cont++;
	  my $test=scalar_prod($start1,$start2,$cont);
          printf("%4d %10.8f %10.8f\n",$cont,$_, $test);
        }
#        printf "@gammaN\n";


######################################################
sub read_evec {
   my ($file,$nevec)=@_;
   my $header;
   my $vec=();
   open (EVEC,"$file") || die "Cannot open $file\n";

   # Testing availability
   my @maxevec= grep {/[0-9]/} ( map {split / +/,$_} (map scalar <EVEC>, 1..2) );
   my $max=$maxevec[2];
   if ( $nevec > $max ) 
   { 
      print "Sorry, $nevec eigenvectors requested (available in $file: $max)\n"; 
      exit; 
   }

   # Reading eigenvectors
   while(<EVEC>){
        chomp;
        $header++ if /\*\*\*\*/ ;
        last if ($header > $nevec);
        push @{$vec->[$header]} ,grep { /[0-9]/ } (split / +/,$_) if ($header);
        }
  close EVEC;
  return $vec;
}

sub gammaN {
	my ($start1,$start2,$N)=@_;
	my $max1=$N+$start1-1;
	my $max2=$N+$start2-1;
        my $alpha;
	my @gammaN;
	my $gamma;
#        for my $i (1 .. $nevec) {
	for my $n (1 .. $N)
	{
		my $end1 = $start1 + $n - 1;
		my $end2 = $start2 + $n - 2;
#		print "loop1 from $start1 to $end1\n";
	        for(my $i = $start1; $i <= $end1; $i++) 
		{
		      	my $dot=0;
			my $dot2=0;
	         	for my $k (2 ..scalar $#{$vec1->[$i]} )
			{ $dot+=$vec1->[$i]->[$k]*$vec2->[$end2+1]->[$k]; 
#			  #print "Screenning i: $i vs $k end2 $end2 $vec1->[$i]->[$k] $vec2->[$end2+1]->[$k]\n";
			}
	        	$dot2=$dot*$dot;
	        	$alpha+=$dot2;
#			print "Screenning i: $i vs $n $vec1->[$i]->[1]\n";
		}
		
#		print "loop2 from $start2 to $end2\n";
	        for(my $j = $start2; $j <= $end2; $j++) 
		{
	               my $dot=0;
			my $dot2=0;
		        # alpha stores the dot product squared
		     	# 0 is index and 1 is the eval (for "k")
	             	for my $k (2 ..scalar $#{$vec2->[$j]} )
			{ $dot+=$vec1->[$end1]->[$k]*$vec2->[$j]->[$k]; 
#			 # print "Screenning j: $j vs $k end1 $end1 $vec1->[$end1]->[$k] $vec2->[$j]->[$k]\n";
			}
	             	$dot2=$dot*$dot;
	             	$alpha+=$dot2;
#			print "Screenning j: $n vs $j\n";
	        }
		my $gamma = $alpha/$n;
# To show the progress, un-comment the next "print"
#		print "gamma($n) = $gamma\n";
		push (@gammaN,$gamma);
	 }
	return (@gammaN);
}


sub gammaN_kk {
	my ($start1,$start2,$N)=@_;
	my $max1=$N+$start1-1;
	my $max2=$N+$start2-1;
        my $alpha;
	my @gammaN;
	my $gamma;
#        for my $i (1 .. $nevec) {
	for my $n (1 .. $N)
	{
		my $end1 = $start1 + $n - 1;
		my $end2 = $start2 + $n - 1;
		print "loop1 from $start1 to $end1\n";
	        for(my $j = $start2; $j <= $end2; $j++) 
	        {
	        for(my $i = $start1; $i <= $end1; $i++) 
		{
		      	my $dot=0;
			my $dot2=0;
	         	for my $k (2 ..scalar $#{$vec1->[$i]} )
			{ $dot+=$vec1->[$i]->[$k]*$vec2->[$j]->[$k]; 
			  print "Screenning i: $i vs $j $k  $vec1->[$i]->[$k] $vec2->[$j]->[$k]\n";
			}
	        	$dot2=$dot*$dot;
	        	$alpha+=$dot2;
#			print "Screenning i: $i vs $n\n";
		}
		}
		
		my $gamma = $alpha/$n;
# To show the progress, un-comment the next "print"
#		print "gamma($n) = $gamma\n";
		push (@gammaN,$gamma);
	 }
	return (@gammaN);
}

sub scalar_prod {
	my ($start1,$start2,$nevec)=@_;
	my $max1=$nevec+$start1-1;
	my $max2=$nevec+$start2-1;
        my $alpha; 
#        for my $i (1 .. $nevec) {
        for my $i ($start1 .. $max1) {
            for my $j ($start2 .. $max2) {
               my $dot=0;
               my $dot2=0;
           
                # 0 is index and 1 is the eval (for "k")
                for my $k (2 ..scalar $#{$vec1->[$i]} )
		{ $dot+=$vec1->[$i]->[$k]*$vec2->[$j]->[$k]; }
	#      print "v1:$vec1->[$i]->[1] v2:$vec2->[$j]->[1]\n";
              $dot2=$dot*$dot;
           #  printf "%8.6f",$dot2;
             $alpha+=$dot2;
             }
         #print "\n";
         }
	#print "$start1 --> $max1   $start2 --> $max2    ";
#	printf "%8.5f\n",$alpha/$nevec;
	return ($alpha/$nevec);
}

sub num_evecs {
   my ($file)=@_;
   my $header;
   my $vec=();
   open (EVEC,"$file") || die "Cannot open $file\n";
   my @maxevec= grep {/[0-9]/} ( map {split / +/,$_} (map scalar <EVEC>, 1..2) );
  close EVEC;
  return $maxevec[2];
}
