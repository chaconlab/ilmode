#!/usr/bin/perl


my @files = ();
#@files =  glob("*.loop.pdb");
@files =  glob("*_REMD.pdb");
foreach $file (@files) {

print "Proccesing $file\n";
my $detect=0;
my $output="";

open (PDB, "<$file") or die "Can't open file $file.\n";
open (OUT, ">temp.pdb") or die "Can't open file temp.pdb\n";
foreach $line (<PDB>) {
     if ($line =~ /^ATOM/ )
   {
        $res_name = substr($line,17,3); # get residue name
        #print "res_num= $res_name\n";
        if ($res_name eq "MSE" )  {
          $line =~ s/MSE/MET/ig;
          $detect =1;
          $output="$file MSE\n";
       }
       if ($res_name eq "FME" )  {
          $detect=1;
          $line =~ s/FME/MET/ig;
          $output="$file FME\n";
       }
       if ($res_name eq "PTR" )  {
          $detect=1;
          $line =~ s/PTR/TYP/ig;
          $output="$file PTR\n";
       }
       if ($res_name eq "PCA" )  {
          $detect=1;
          $line =~ s/PCA/GLU/ig;
          $output="$file PCA\n";
       }
       if ($res_name eq "SEP" )  {
          $detect=1;
          $line =~ s/SEP/SER/ig;
          $output="$file SEP\n";
       }
       if ($res_name eq "HIC" )  {
          $detect=1;
          $line =~ s/HIC/HIS/ig;
          $output="$file HIC\n";
       }
        if ($res_name eq "HIE" )  {
          $detect=1;
          $line =~ s/HIE/HIS/ig;
          $output="$file HIE\n";
       }
        if ($res_name eq "HID" )  {
          $detect=1;
          $line =~ s/HID/HIS/ig;
          $output="$file HID\n";
       }
       if ($res_name eq "CSE" )  {
          $detect=1;
          $line =~ s/CSE/CYS/ig;
          $output="$file CSE\n";
       }
       if ($res_name eq "PYL" )  {
          $detect=1;
          $line =~ s/PYL/LYS/ig;
          $output="$file PYL\n";
       }
       if ($res_name eq "OCS" )  {
          $detect=1;
          $line =~ s/OCS/CYS/ig;
          $output="$file OCS\n";
       }
       if ($res_name eq "MLY" )  {
          $detect=1;
          $line =~ s/MLY/LYS/ig;
          $output="$file MLY\n";
       }
      if ($res_name eq "KCX" )  {
          $detect=1;
          $line =~ s/KCX/LYS/ig;
          $output="$file KCX\n";
       }
       if ($res_name eq "CSD" )  {
          $detect=1;
          $line =~ s/CSD/ALA/ig;
          $output="$file ALA\n";
       }
 	if ($res_name eq "DAL" )  {
          $detect=1;
          $line =~ s/DAL/ALA/ig;
          $output="$file ALA\n";
       }
       if ($res_name eq "LLP" )  {
          $detect=1;
          $line =~ s/LLP/LYS/ig;
          $output="$file LYS\n";
       }
      if ($res_name eq "CGU" )  {
          $detect=1;
          $line =~ s/CGU/GLU/ig;
          $output="$file GLU\n";
       }
       if ($res_name eq "CME" )  {
          $detect=1;
          $line =~ s/CME/CYS/ig;
          $output="$file CYS\n";
       }
       if ($res_name eq "TPO" )  {
          $detect=1;
          $line =~ s/TPO/THR/ig;
          $output="$file THR\n";
       }
       if ($res_name eq "DAR" )  {
          $detect=1;
          $line =~ s/DAR/ARG/ig;
          $output="$file ARG\n";
       }
       if ($res_name eq "HYP" )  {
          $detect=1;
          $line =~ s/HYP/PRO/ig;
          $output="$file PRO\n";
       }



    }
	print OUT $line;
}


close(PDB);
close(OUT);

if ($detect==1)  {
print "saving $file $output\n";
system("cp temp.pdb $file\n");
}



}
