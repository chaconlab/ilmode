#!/usr/bin/perl
# Manuel Rueda 10/06

# Compute B-factors directly from ptraj evec/eval file

# Can be used with NMA/ED 

#
# Modified by Mon (27/6/2007)
# by default it saves a text-file with b-factors
# if you put a pdb-file name in the corresponding field, then it will also save a PDB-file
#

use strict;
# use File::Basename;


if ($#ARGV != 3) 
{ 
	print "USAGE: \n\t$0";
	print "\n\t[ptraj_evec] [nma/pca] [null/not] [factor]\n";
	print "Description: \n";
	print "\tComputes Bfactors taking into account everything (nma/pca & null modes)\n\n";
	exit;
}

#	Loading things        
        my $file=$ARGV[0];
	my $type=$ARGV[1];
	my $null=$ARGV[2]; # To discard the 6 first NULL modes ( "1" )
	my $factor=$ARGV[3];
	my $debug=0;

#       fundamental constants and Temp
        my $BOLTZ=0.00198717;
        my $TEMP=300;
        my $KbT=$BOLTZ*$TEMP; 
        my $pi=2*atan2(1,0);


	#Declared now and loaded below
	my ($first,$last,$max);
	# Defining some needed parameters...
	# Accounts for the different modes procedence (NMA or ED).
	if($type eq 'nma') 
	{  # NMA
		# Easy way to get the total number of vectors from "ptraj" header!
	        $max = `awk 'NR == 2 {print \$4}' $file`;
		chomp($max);
		
		if($null eq 'null') { $first = 6; }
		else { $first = 0; }
		$last = $max;
	}
	else { 	# ED
		# Easy way to get the total number of vectors from "ptraj" header!
	        $max = `awk 'NR == 2 {print \$2}' $file`;
		chomp($max);

		if($null eq 'null') {  $last = ($max - 6); }
		else { $last = $max; }
		$first = 0; 
	}

############################


	my $N;  # Number of atoms (from ptraj)
	my $N3; # Number of elements

#	Loading eigenvector file
        my ($vec,$N)=read_evec($file,$last,$first);
	print "Number of Atoms (from ptraj_file) = $N\n" if($debug);
# exit;
	my $nevec=$factor*$N;
	if ($nevec > ($last-$first) ) { $nevec=($last-$first); } # Whether maximum exceeded... then set tu maximum!

	# This gets the number of atoms from the ptraj-file
	$N3=3*$N;
	
	if($debug) { for(my $i=0;$i<$nevec;$i++) { printf "Mode: %4d    Eigenvalue: $vec->[$i]->[1]\n",$i+1;} }
	
#	Computing B-FACTOR
	cum_bfactor($nevec,$N,$first+1);

       
#################################################################
sub read_evec {
        my ($file,$nevec,$start)=@_;
        my $header;
        my $vec=();
        open (EVEC,"$file") || die "Cannot open $file\n";
        my @maxevec= grep {/[0-9]/} ( map {split / +/,$_} (map scalar <EVEC>, 1..2) );
        my $max=$maxevec[0];
#	print "max: $max\n"; return $vec;
#        my $max=$maxevec[0]-6;
        if ( $nevec > $max ) 
	{ 
		print "More modes requested than available ($nevec is greater than $max)\n"; 
		exit;
	}
	printf "# Msg(read_evec): Reading eigenvectors from %d to %d in $file\n",($start+1),$nevec if($debug);
	my $cont;
        while(<EVEC>){
                chomp;
                $header++ if /\*\*\*\*/ ; #$VEC start from 1, elements from 0  
                last if ($header > $nevec);
#		printf "$cont index:%d\n",$header-$start if ($header && $header > $start);
                push @{$vec->[$header-$start]} ,grep { /[0-9]/ } (split / +/,$_) if ($header && $header > $start) ; 
#		$cont++ if ($header && $header > $start);
        }
        close EVEC;
	my $N = ($#{$vec->[1]} - 1)/3;
        return ($vec,$N);
}

sub cum_bfactor {
	my $vectors=shift;
	my $natom=shift;
	my @fluc2=(); #start at 1
   	my $norme;
#	if ($null eq 'null') { $start = 7; }
#	else { $start = 1; }

#	Obtaining the mean square displacements
	print "Obtaining the mean square displacements from 1 to $vectors eigenvectors\n" if($debug);
      	for my $i (1 .. $vectors) {
       	my $inc=0;
#	print "$vec1->[$i]->[1]\n";
         	for my $k (1 .. $natom)    
		{
         	$norme=$vec->[$i]->[$inc+2]**2 + $vec->[$i]->[$inc+3]**2 + $vec->[$i]->[$inc+4]**2;
		if($vec->[$i]->[1] >0) { $fluc2[$k] += $norme/$vec->[$i]->[1] if $type eq 'nma'; } # Manu
		$fluc2[$k] += $norme*$vec->[$i]->[1] if $type eq 'pca'; # Mon2
         	$inc=$inc+3;
         	}
     	} 
#	Multiply by $KbT=<Dr^2> and obtain B-factors (Mass = 1)
# 	The KbT factor can be put also before the sumatory (more calculations)
	my @bfact=();
	my $num=1;
	
      	if ($type eq 'nma') 
	{
		for my $k (1 .. $natom) 
		{
	         	$bfact[$k]=8*$pi**2*$KbT*$fluc2[$k]/3; # Manu
	         	printf  "%8i %12.4f %12.4f\n",$num,$bfact[$k],$fluc2[$k];
			$num++;
	    	}
	}
	
      	if ($type eq 'pca')
	{
		for my $k (1 .. $natom)
		{
	         	$bfact[$k]=8*$pi**2*$fluc2[$k]/3; # Mon
	         	printf  "%8i %12.4f %12.4f\n",$num,$bfact[$k],$fluc2[$k];
#	         	printf  "%8i %12.4f\n",$num,$bfact[$k];
			$num++;
	    	}
	}
}

