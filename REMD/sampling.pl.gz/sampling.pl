#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
   #$cmd = " grep \" N \\| CA \\| C \" $l[0]_refPDB.pdb >  $l[0]_NCAC.pdb";
   # $cmd = " python MDbb.py  $l[0].loop.pdb  $l[0]_REMD.pdb";
   # print "$cmd\n";
   # system($cmd);
   
    $cmd = "grep \" N \\| CA \\| C \" $l[0]_refPDB.pdb >  $l[0]_refPDBNCAC.pdb";
    system($cmd);


# MD
$cmd = "korpe_gcc $l[0]_refPDBNCAC.pdb --loops $l[0]_REMD_H2.pdb  --score_file ~/rcd2020/korp6Dv1.bin -o k1 ; 
rmsd $l[0]_ref2.pdb $l[0]_REMD_H2.pdb  -b --res_offset 1 > rmsd1;
rmsd ../alignPDBs/pdbsA/$l[0]_loopANCAC.pdb  $l[0]_REMD_H2.pdb  -b --res_offset 1 > rmsd2;
paste k1.txt rmsd1 rmsd2 > s_$l[0].txt";
print "$cmd\n";
system($cmd);

# Ilmode
$cmd = "korpe_gcc $l[0]_refPDBNCAC.pdb --loops $l[0]_refPDB_traj.pdb  --score_file ~/rcd2020/korp6Dv1.bin -o k2  ;
rmsd $l[0]_ref2.pdb $l[0]_refPDB_traj.pdb  -b --res_offset 1 > rmsd1;
rmsd ../alignPDBs/pdbsA/$l[0]_loopANCAC.pdb  $l[0]_refPDB_traj.pdb  -b --res_offset 1 > rmsd2;
paste k2.txt rmsd1 rmsd2 > s2_$l[0].txt";
print "$cmd\n";
system($cmd);


# RCD
$cmd = "korpe_gcc $l[0]_refPDBNCAC.pdb --loops rcd/$l[0]_refPDB_closed.pdb  --score_file ~/rcd2020/korp6Dv1.bin -o k3; 
rmsd $l[0]_ref2.pdb rcd/$l[0]_refPDB_closed.pdb   -b --res_offset 1 > rmsd1;
rmsd ../alignPDBs/pdbsA/$l[0]_loopANCAC.pdb rcd/$l[0]_refPDB_closed.pdb  -b --res_offset 1 > rmsd2;
paste k3.txt rmsd1 rmsd2 > s3_$l[0].txt";
print "$cmd\n";
system($cmd);

# RCD 5
#$cmd = "korpe_gcc $l[0]_refPDBNCAC.pdb --loops rcd5/$l[0]_refPDB_closed.pdb  --score_file ~/rcd2020/korp6Dv1.bin -o k3; 
#rmsd $l[0]_ref2.pdb rcd5/$l[0]_refPDB_closed.pdb   -b --res_offset 1 > rmsd1;
#rmsd ../alignPDBs/pdbsA/$l[0]_loopANCAC.pdb rcd5/$l[0]_refPDB_closed.pdb  -b --res_offset 1 > rmsd2;
#paste k3.txt rmsd1 rmsd2 > s4_$l[0].txt";
#print "$cmd\n";
#system($cmd);

#$cmd = "korpe_gcc $l[0]_refPDBNCAC.pdb --loops $l[0]_rcdB_traj.pdb  --score_file ~/rcd2020/korp6Dv1.bin -o k4  ;
#rmsd $l[0]_ref2.pdb $l[0]_rcdB_traj.pdb  -b --res_offset 1 > rmsd1;
#rmsd ../alignPDBs/pdbsA/$l[0]_loopANCAC.pdb  $l[0]_rcdB_traj.pdb  -b --res_offset 1 > rmsd2;
#paste k4.txt rmsd1 rmsd2 > s4_$l[0].txt";
#print "$cmd\n";
#system($cmd);





#   print "plot \"s_$l[0].txt\" u 7:2 w d, \"s2_$l[0].txt\" u 7:2 w d, \"s3_$l[0].txt\" u 7:2 w d\n";
  
}    

