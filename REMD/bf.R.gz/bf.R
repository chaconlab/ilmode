#Libraries
library(ggplot2)
library(ggpubr)
library(dplyr)
library(stringr)
library(reshape2)
library(RColorBrewer)
library(cowplot)
library(ggpmisc)
library(hrbrthemes)

setwd("/home/pablo/ilmode/wu/REMD")



pdbs = c("2eaq", "5w0g", "2ns0","4dpb","5nod","6elm","3bv8","5e9p","4bpf","6fmb","5k2l","3k3v","3fdr", "4qy7","3dkm")
pl <- list()  # new empty plot list

i=1;

file = sprintf("BF_2eaq.txt", pdbs[i])
my_data <- read.table(file)

#df <- my_data[-c(1:3), ]
#rows = nrow(df)-2
#my_data<- df[-c(rows:nrow(df)), ]

r <- cor.test(my_data$V5, my_data$V6,  method = "pearson")
k <- cor.test(my_data$V5, my_data$V6,  method="kendall", exact=FALSE)
s <-cor.test(my_data$V5, my_data$V6,  method = "spearman", exact=FALSE)
sprintf("%s %f %f %f\n", pdbs[i], r$estimate,k$estimate, s$estimate )

my_data$V8=my_data$V8-my_data$V8[1]
my_data$V6=my_data$V6-my_data$V6[1]

labelr=sprintf("s=%0.2f", s$estimate)
labelk=sprintf("r=%0.2f", r$estimate)
labels=sprintf("k=%0.2f", k$estimate)


rows = length(my_data$V3);
sequence <- my_data$V3[seq(2,rows,3)]
sequenceB  <- my_data$V1[seq(2,rows,3)]

bf<-ggplot(data = my_data, aes(x = V1)) +
  geom_line(aes(y = V5), color="darkblue",size=1) +
  geom_line(aes(y = V6), color="darkorange",size=1) +
  geom_line(aes(y = V8), color="green",size=1 ) +
  
  
  scale_x_continuous(breaks=sequenceB, label = sequence ) +
  annotate("text_npc",npcx = 0.1, npcy = 0.95, label =  labelr ,size = 6) +
  annotate("text_npc",npcx = 0.1, npcy = 0.90, label =  labelk ,size = 6) +
  annotate("text_npc",npcx = 0.1, npcy = 0.85, label =  labels ,size = 6) +
  theme(plot.title = element_text(size = 24, face = "bold"),
          axis.title.y=element_blank() , axis.text.x = element_text(size = 20, face = "bold"))
  
  ggtitle(pdbs[i])

 print(bf)





 for (i in 1:length(pdbs)) {
  file = sprintf("BF_%s.txt", pdbs[i])
  my_data <- read.table(file)
  my_data$V8=my_data$V8-my_data$V8[1]
  my_data$V6=my_data$V6-my_data$V6[1]
  
 # df <- my_data[-c(1:3), ]
#rows = nrow(df)-2
#  my_data<- df[-c(rows:nrow(df)), ]
  r <- cor.test(my_data$V5, my_data$V6,  method = "pearson")
  k <- cor.test(my_data$V5, my_data$V6,  method="kendall", exact=FALSE)
  s <-cor.test(my_data$V5, my_data$V6,  method = "spearman", exact=FALSE)
  sprintf("%s %f %f %f\n", pdbs[i], r$estimate,k$estimate, s$estimate )

  labelr=sprintf("s=%0.2f", s$estimate)
  labelk=sprintf("r=%0.2f", r$estimate)
  labels=sprintf("k=%0.2f", k$estimate)
  
  rows = length(my_data$V3);
  sequence <- my_data$V3[seq(2,rows,3)]
  sequenceB  <- my_data$V1[seq(2,rows,3)]
  
  
  bf<-ggplot(data = my_data, aes(x = V1)) +
    geom_line(aes(y = V5), color="darkblue",size=1.2) +
    geom_line(aes(y = V6), color="darkorange",size=1.2) +
   geom_line(aes(y = V8), color="green",size=1.2 ) +
    scale_x_continuous(breaks=sequenceB, label = sequence ) +
    theme_ipsum() +
#  annotate("text_npc",npcx = 0.1, npcy = 0.95, label =  labelr ,size = 6) +
#  annotate("text_npc",npcx = 0.1, npcy = 0.90, label =  labelk ,size = 6) +
#  annotate("text_npc",npcx = 0.1, npcy = 0.85, label =  labels ,size = 6) +
    theme(plot.title = element_text(size = 32), 
          axis.text.x = element_text(size = 20, face = "bold"), 
          axis.title.x=element_blank(),  axis.title.y=element_blank()) + 
  
  ggtitle(pdbs[i])
  pl[[i]] <-   bf
  
#  print(bf)
}
plot_grid(plotlist = pl, ncol = 3)

