#!/usr/bin/perl

my $file=$ARGV[0];
my $frame=$ARGV[1];



    open(IN, $file) or die "Could not read file";

    $pat=sprintf ("MODEL      %-5d",$frame);
    $pat=~ s/\s+$//;
    print "$pat\n";
    while ($li = <IN>) {
    last if (($li =~ s/(^MODEL)//) && ($li =~ s/$frame//)); 
    }

    while ($li = <IN>) {
    last if $li =~ s/^MODEL//;
    print $li;
    }
    close(IN);
    

