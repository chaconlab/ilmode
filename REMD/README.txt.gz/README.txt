MDbb_run.pl 
chainMD.sh
pcatoolMD2.pl
compareMD.pl
pcatoolMD.pl
pdb2refloop.pl
ilmode.pl
pcatool.pl
compare.pl
rcd.pl
evecRCD.pl
pcatoolRCD.pl


tableMD.pl
table.pl
tableRCD.pl



pcatoolMD.pl
chain2.sh
pdb2refloop.pl
pcatool.pl
compare.pl
table.pl
bf_plot.pl

2eaq 12  1.60  1.41  1.47  1.01  0.59  0.91  3  0.68  0.96  6  0.70  0.97  0.93  0.79  0.99  0.99 35  0.78  0.88  18259  60.4
5w0g 12  1.09  0.55  1.04  0.69  0.69  0.91  7  0.75  0.95 11  0.70  0.94  0.95  0.77  0.98  0.99 35  0.35  0.61  12007  28.0
2ns0 12  0.69  0.20  0.70  0.46  0.70  0.91  9  0.75  0.95 15  0.70  0.91  0.94  0.76  0.97  0.99 35  0.94  0.97   7998  21.2
4dpb 12  0.74  0.46  0.77  0.50  0.73  0.90  7  0.81  0.95 13  0.73  0.93  0.94  0.81  0.98  0.99 35  0.70  0.80   8429  23.9
5nod 12  1.03  0.37  0.90  0.59  0.82  0.92  5  0.81  0.95  9  0.81  0.95  0.95  0.82  0.98  0.99 35  0.94  0.91   9984  21.3
6elm 12  1.61  0.80  1.59  1.07  0.72  0.91  7  0.78  0.96 11  0.74  0.94  0.95  0.79  0.98  0.99 35  0.88  0.92  18450  63.1
3bv8 13  0.52  0.16  0.57  0.36  0.79  0.91 14  0.74  0.94 19  0.73  0.84  0.94  0.74  0.94  0.99 38  0.96  0.96   5994  14.9
5e9p 14  2.77  0.96  2.55  1.76  0.74  0.91  4  0.70  0.96  7  0.70  0.97  0.96  0.75  0.99  0.99 41  0.92  0.96  28124 103.9
4bpf 15  1.37  1.07  1.40  0.95  0.44  0.90  4  0.66  0.95  8  0.67  0.96  0.92  0.79  0.99  0.98 44  0.87  0.92  16037  57.7
6fmb 15  1.07  0.59  1.09  0.72  0.77  0.91  9  0.78  0.95 14  0.77  0.91  0.93  0.76  0.97  0.98 44  0.73  0.77  12285  53.0
5k2l 15  0.73  0.35  0.77  0.50  0.72  0.90 10  0.79  0.95 17  0.75  0.89  0.94  0.81  0.96  0.99 44  0.91  0.94   8436  23.4
3k3v 16  3.74  1.69  3.62  2.51  0.71  0.90  5  0.76  0.96  9  0.76  0.96  0.96  0.79  0.99  0.99 47  0.94  0.96  39605 147.8
3fdr 16  1.20  1.28  1.23  0.82  0.77  0.91  6  0.76  0.95 10  0.78  0.95  0.91  0.79  0.98  0.98 47  0.73  0.71  14156  58.0
4qy7 16  1.36  0.80  1.39  0.94  0.63  0.91  5  0.75  0.95  9  0.75  0.95  0.92  0.79  0.98  0.98 47  0.19  0.62  14849  51.3
3dkm 18  4.33  3.10  4.18  2.85  0.77  0.92  6  0.75  0.95  9  0.75  0.95  0.96  0.79  0.99  0.99 53  0.89  0.91  45722 216.7
     14  1.59  0.92  1.55  1.05  0.71  0.91  6  0.75  0.95 11  0.74  0.93  0.94  0.78  0.98  0.99 41  0.78  0.86  17355  63.0


RCD
rcd.pl
cp rcd/????_refPDB_closed.pdb  .
./evecRCD.pl
pcatoolRCD.pl
compareRCD.pl
tableRCD.pl

2eaq 12  1.60  1.41  6.26  1.73  0.67  0.91  3  0.72  0.96  6  0.71  0.97  0.96  0.82  0.99  0.99 35  0.90  0.97  18259  60.4 105.3   1.7
5w0g 12  1.09  0.55  5.93  1.94  0.68  0.91  7  0.71  0.95 11  0.69  0.94  0.96  0.81  0.98  0.99 35  0.75  0.83  12007  28.0  47.8   1.7
2ns0 12  0.69  0.20  5.77  1.90  0.65  0.91  9  0.64  0.95 15  0.65  0.91  0.96  0.68  0.97  0.99 35  0.62  0.81   7998  21.2  32.0   1.5
4dpb 12  0.74  0.46  5.95  2.50  0.67  0.90  7  0.73  0.95 13  0.74  0.93  0.97  0.77  0.98  0.99 35  0.26  0.55   8429  23.9  75.4   3.2
5nod 12  1.03  0.37  8.64  3.72  0.60  0.92  5  0.70  0.95  9  0.70  0.95  0.98  0.74  0.98  0.99 35  0.87  0.91   9984  21.3  63.3   3.0
6elm 12  1.61  0.80  3.71  1.12  0.67  0.91  7  0.76  0.96 11  0.71  0.94  0.94  0.81  0.98  0.99 35  0.86  0.92  18450  63.1 139.9   2.2
3bv8 13  0.52  0.16  5.18  1.85  0.73  0.91 14  0.69  0.94 19  0.72  0.84  0.95  0.69  0.94  0.99 38  0.63  0.73   5994  14.9  47.6   3.2
5e9p 14  2.77  0.96  7.38  2.19  0.67  0.91  4  0.71  0.96  7  0.70  0.97  0.94  0.74  0.99  0.98 41  0.94  0.99  28124 103.9 168.0   1.6
4bpf 15  1.37  1.07  6.34  1.33  0.44  0.90  4  0.67  0.95  8  0.69  0.96  0.94  0.76  0.99  0.98 44  0.76  0.89  16037  57.7 102.7   1.8
6fmb 15  1.07  0.59  8.89  2.04  0.72  0.91  9  0.71  0.95 14  0.72  0.91  0.95  0.72  0.97  0.99 44  0.67  0.77  12285  53.0  52.0   1.0
5k2l 15  0.73  0.35  8.90  3.31  0.68  0.90 10  0.72  0.95 17  0.64  0.89  0.96  0.74  0.96  0.99 44  0.86  0.89   8436  23.4  42.8   1.8
3k3v 16  3.74  1.69  8.85  2.41  0.75  0.90  5  0.74  0.96  9  0.74  0.96  0.96  0.79  0.99  0.99 47  0.95  0.93  39605 147.8 203.0   1.4
3fdr 16  1.20  1.28  7.77  2.51  0.74  0.91  6  0.73  0.95 10  0.76  0.95  0.95  0.77  0.98  0.98 47  0.91  0.92  14156  58.0 310.2   5.3
4qy7 16  1.36  0.80  7.35  2.84  0.54  0.91  5  0.72  0.95  9  0.72  0.95  0.96  0.76  0.98  0.99 47  0.09  0.57  14849  51.3 418.0   8.1
3dkm 18  4.33  3.10 11.75  3.27  0.77  0.92  6  0.80  0.95  9  0.80  0.95  0.95  0.80  0.99  0.98 53  0.87  0.87  45722 216.7 334.4   1.5
     14  1.59  0.92  7.24  2.31  0.67  0.91  6  0.72  0.95 11  0.71  0.93  0.96  0.76  0.98  0.99 41  0.73  0.84  17355  63.0 142.8   2.6
     
     
tar -cvzf bf.tgz  BF_*.txt 


pcatoolMD.pl
chain.sh
ilmode.pl
pcatool.pl
compare.pl
table.pl

for RCD
./evecRCD.pl
pcatoolRCD.pl
compareRCD.pl
table.pl

perl ~/PROGS/scripts_mon/NMAbf.pl 5w0g.evec pca not 1.0 > bfmd.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 5w0g_ilmode.evec pca not 1.0 > bfilmode.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00

perl ~/PROGS/scripts_mon/NMAbf.pl 4dpb_ilmode.evec pca not 1.0 > bfilmode.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 4dpb.evec pca not 1.0 > bfmd.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00

perl ~/PROGS/scripts_mon/NMAbf.pl 6elm.evec pca not 1.0 > bfmd.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 6elm_ilmode.evec pca not 1.0 > bfilmode.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00

perl ~/PROGS/scripts_mon/NMAbf.pl 2eaq_ilmode.evec pca not 1.0 > bfilmode.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 2eaq.evec pca not 1.0 > bfmd.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00

perl ~/PROGS/scripts_mon/NMAbf.pl 6fmb_ilmode.evec pca not 1.0 > bfilmode.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 6fmb.evec pca not 1.0 > bfmd.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00

perl ~/PROGS/scripts_mon/NMAbf.pl 3dkm_ilmode.evec pca not 1.0 > bfilmode.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 3dkm.evec pca not 1.0 > bfmd.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00


perl ~/PROGS/scripts_mon/NMAbf.pl 2ns0_ilmode.evec pca not 1.0 > bfilmode.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 2ns0.evec pca not 1.0 > bfmd.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00

perl ~/PROGS/scripts_mon/NMAbf.pl 3k3v_ilmode.evec pca not 1.0 > bfilmode.txt
perl ~/PROGS/scripts_mon/NMAbf.pl 3k3v.evec pca not 1.0 > bfmd.txt
perl corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00



