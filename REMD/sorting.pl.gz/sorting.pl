#!/usr/bin/perl


my @recordsArray;
my @headers;

open(IN, "k2.txt") or die "Could not read file";

while(my $line = <IN>) {
  chomp $line;
   
  next unless $line; # skip blank lines
   
  if ($. == 1) { # first line?
    @headers = split(/\s+/, $line);
    next;
  }

  push @recordsArray, [ split(/\s+/, $line) ]; # store array ref
}

close(IN);

for(my $i = 0; $i <= 10; $i++){
print "$sorted_array[$i]->[1] $sorted_array[$i]->[2]\n";
}



# sort first on column 2 (score), then on column 3 (value)
# column 3 will only be used when column 2 values are the same
my @sorted_array =   sort { 
    $b->[2] <=> $a->[2] 
} @recordsArray;


for(my $i = 0; $i <= 10; $i++){
print "$sorted_array[$i]->[1] $sorted_array[$i]->[2]\n";
}


