#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";
my $li;
my $col=0;
@columns = (1 .. 20);

    open(IN, "randomRCD.txt") or die "Could not read file";
    my @zsc=();
    while ($li = <IN>) {
        chomp($li);
        push @zsc, $li ;
    }
    close(IN);


my $cont=0;
while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
        
    ## read var ref
    open(IN, "$l[0]_ilmode.log") or die "Could not read file";
    while ($li = <IN>) {
    last if $li =~ s/pcatool> Average rmsd from ref://;
    }
    my @f = split(/\s+/, $li);  
    my $avg=$f[1];
    my $sig=$f[2];
    
    while ($li = <IN>) {
    last if $li =~ s/pcatool> Showing the//;
    }
    my @f = split(/\s+/, $li);
    $nevec=$f[1];
    

    
    while ($li = <IN>) {
    last if $li =~ s/MODE EIGENVALUE //;
    }
    my @var=();
    for (my $i=0; $i< $nevec ; $i++) {
    my @f = split(/\s+/, <IN>);
    push @var, $f[3] ;
    }

     my $i90;
     $i90=$nevec-1;
     for (my $i=0; $i< $nevec ; $i++) {
        if ($var[$i] > 0.90) {
       $i90=$i; $i=$nevec;    
   }
   }
    my $i95;
    $i95=$nevec-1;
     for (my $i=0; $i< $nevec ; $i++) {
        if ($var[$i] > 0.95) {
       $i95=$i;  $i=$nevec;        
   }}
   
    #print " nevec $nevec $i95 $i90 \n";
    close(IN);
    
    ## read var ilmode
    open(IN, "$l[0]_rcd.log") or die "Could not read file";
        while ($li = <IN>) {
    last if $li =~ s/pcatool> Average rmsd from ref://;
    }
    my @f = split(/\s+/, $li);  
    my $avg2=$f[1];
    my $sig2=$f[2];
    
     while ($li = <IN>) {
    last if $li =~ s/pcatool> Showing the//;
    }
    my @f = split(/\s+/, $li);
    $nevec2=$f[1];
    
    while ($li = <IN>) {
    last if $li =~ s/MODE EIGENVALUE //;
    }
    my @var2=();
    for (my $i=1; $i<= $nevec2 ; $i++) {
    my @f = split(/\s+/, <IN>);
    push @var2, $f[3] ;
    }
    close(IN);
    
    my $i902;
     $i902=$nevec2-1;
     for (my $i=0; $i< $nevec2 ; $i++) {
        if ($var2[$i] > 0.90) {
       $i902=$i; $i=$nevec2;    
   }
   }
    my $i952;
    $i952=$nevec2-1;
     for (my $i=0; $i< $nevec2 ; $i++) {
        if ($var2[$i] > 0.95) {
       $i952=$i;  $i=$nevec2;        
   }}
   
    
    
    
    ## read gamma
    open(IN, "$l[0]_gamma_rcdi.txt") or die "Could not read file";
    my @gamma=();
    while ($li = <IN>) {
    my @f = split(/\s+/, $li);
    push @gamma, $f[2] ;
    }
    close(IN);

    ## read bf
    open(IN, "$l[0]_bf_rcdi.txt") or die "Could not read file";
    $li = <IN>;
    $li = <IN>;
    my @f = split(/\s+/, $li);
    my $atoms=$f[2];
    my $coor=$f[3];
    my $sperm=$f[4];
    close(IN);

    
    # read ilmode 
    open(IN, "$l[0]_ref.log") or die "Could not read file";
    while ($li = <IN>) {
    last if $li =~ s/ilmode> Number of residues in loop: //;
    }
    chomp($li);
    $res=$li;
    while ($li = <IN>) {
    last if $li =~ s/ilmode> Saved//;
    }
    my @f = split(/\s+/, $li);  
    $ntraj=$f[1];
    while ($li = <IN>) {
    last if $li =~ s/Processed in//;
    }
    my @f = split(/\s+/, $li); 
    $time=$f[1];
    close(IN);
    
    #zscore
    my @f = split(/\s+/, $zsc[$cont]);
  

    if ($f[2]<0.001) {$f[2]=0.001};
    if ($f[4]<0.001) {$f[4]=0.001};
    if ($f[6]<0.001) {$f[6]=0.001};
    if ($f[8]<0.001) {$f[8]=0.001};
    my $zsc90=($gamma[$i90]-$f[1])/$f[2];
    my $zsc95=($gamma[$i95]-$f[3])/$f[4];  
     my $zsc9=($gamma[9]-$f[5])/$f[6];         
    my $zsc19=($gamma[19]-$f[7])/$f[8];  
              
    #print "hola $f[0] $f[1] $f[2] - $f[3] $f[4]  - $f[5] $f[6]  - $f[7] $f[8] -- $gamma[$i90] $gamma[$i90] $gamma[9] $gamma[19] --- $zsc90\n";



       
    $cont++;
    
    
    
   # for (my $i=1; $i<= $#var ; $i++) {
   #      print "$i $gamma[$i] $var[$i] $var2[$i]\n";
   # } 

  
   #print "$l[0] $res $avg $sig $avg2 $sig2 $gamma[$i90] $var[$i90] $i90 $gamma[$i95] $var[$i95] $i95  $gamma[9] $var[9] $var2[9] $gamma[19] $var[19] $var2[19]  $ntraj $time\n";

  my $row = sprintf ("%4s %2d %5.2f %5.2f %5.2f %5.2f %5.3f %5.0f %5.2f %2d %2d %5.3f %5.0f %5.2f %2d %2d %5.3f %5.0f %5.2f %5.2f %5.3f %5.0f %5.2f %5.2f %2d %5.2f %5.2f %6d %5.1f\n",
     $l[0],$res,$avg,$sig,$avg2,$sig2,$gamma[$i90],$zsc90, $var[$i90],$i90, $i902, $gamma[$i95], $zsc95, $var[$i95], $i95, $i952, $gamma[9], $zsc9, $var[9], $var2[9], $gamma[19], $zsc19, $var[19], $var2[19],  $atoms, $coor, $sperm, $ntraj, $time);
      
    print $row;
    push @column, $row ;
   $col++;
   
}    
  
 my $arr=(); 
 my $ncol;
 for (my $i=0; $i<= $#column ; $i++) 
 {
     my @f = split(/\s+/, $column[$i]);
        $ncol=$#f;
       for (my $j=1; $j<= $ncol ; $j++) {
          $arr[$j]+=$f[$j];
       }     
   
 }

for (my $j=1; $j<= $ncol ; $j++) {
          $arr[$j]/=($#column+1);
       }   
     
$blank=" ";       
printf ("%4s %2d %5.2f %5.2f %5.2f %5.2f %5.3f %5.0f %5.2f %2d %2d %5.3f %5.0f %5.2f %2d %2d %5.3f %5.0f %5.2f %5.2f %5.3f %5.0f %5.2f %5.2f %2d %5.2f %5.2f %6d %5.1f\n",
     $blank,$arr[1],$arr[2],$arr[3],$arr[4],$arr[5],$arr[6],$arr[7],$arr[8], $arr[9], $arr[10], $arr[11], $arr[12], $arr[13], $arr[14], $arr[15],
      $arr[16], $arr[17],  $arr[18], $arr[19], $arr[20],  $arr[21], $arr[22], $arr[23], $arr[24], $arr[25], $arr[26],  $arr[27], $arr[28]);
       
       



close(fh);
