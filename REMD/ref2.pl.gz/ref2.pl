#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    

    
    $cmd = "selectFrame.pl  $l[0]_refPDB_traj.pdb  1 > temp;\n";
    print "$cmd\n";
    system($cmd);
    
    $cmd = "grep \" N \\| CA \\| C \" temp  >  $l[0]_refNCAC.pdb ";
      print "$cmd\n";
    system($cmd);
    
  
  
}    

