#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    #$cmd = "gamma.pl $l[0].evec $l[0]_ilmode.evec 20 1 1 > $l[0]_gamma.txt\n";
    #$cmd = "gamma.pl $l[0]_wpca.evec $l[0]_ilmode_wpca.evec 20 1 1 > $l[0]_gamma_wpca.txt\n";
    #print $cmd;
    #system($cmd);
    
    $cmd = "gamma.pl $l[0].evec $l[0]_rcd.evec 50 1 1 > $l[0]_gamma_rcd.txt\n";
    $cmd = "gamma.pl $l[0]H2.evec $l[0]_rcd.evec 50 1 1 > $l[0]_gamma_rcd.txt\n";
    print $cmd;
    system($cmd);
    
    $cmd = "./NMAbf.pl $l[0].evec pca not 1.0 > bfmd.txt; NMAbf.pl  $l[0]_rcd.evec pca not 1.0 > bfilmode.txt; corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00 >  $l[0]_bf_rcd.txt\n";
    $cmd = "./NMAbf.pl $l[0]H2.evec pca not 1.0 > bfmd.txt; NMAbf.pl  $l[0]_rcd.evec pca not 1.0 > bfilmode.txt; corrs3.pl  bfmd.txt bfilmode.txt 3 3 1 all 0.00 >  $l[0]_bf_rcd.txt\n";
    print $cmd;
    system($cmd);
}    

