#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    
    # get full atom loop
    open(IN, "$l[0].log") or die "Could not read file";
    while ($li = <IN>) {
    last if $li =~ s/-th structure as reference//;
    }
    my @f = split(/\s+/, $li); 
    close(IN); 
   
    
    $cmd = "selectFrame.pl  $l[0].loop.pdb  $f[3] > temp; pdb_chain -A temp > $l[0]_ref_full.pdb\n";
    #print "$cmd\n";
    system($cmd);
    
    #insert loop
    
    $cmd = " grep \" N \\| CA \\| C \" $l[0]_ref_full.pdb >  $l[0]_ref_fullNCAC.pdb";
    system($cmd);
    
    $cmd = " grep \" N \\| CA \\| C \" ../$l[0].300ns_frame.pdb >  $l[0]_NCAC.pdb";
    system($cmd);
        
    
    $cmd = "../insertpdb.pl $l[0]_ref_full.pdb  ../$l[0].300ns_frame.pdb  $l[0]_refPDB.pdb noanchors\n"; 
    $cmd = "../insertpdb.pl $l[0]_ref_full.pdb  ../$l[0].300ns_frame.pdb  $l[0]_kk.pdb > log \n"; 
    $cmd = "../insertpdb.pl $l[0]_ref_full.pdb  ../$l[0].300ns_frame.pdb  $l[0]_kk.pdb > log \n"; 
    $cmd = "../insertpdb.pl $l[0]_ref_fullNCAC.pdb  $l[0]_NCAC.pdb  $l[0]_kk.pdb > log \n"; 
    #print "$cmd\n";
    system($cmd);
    
    
    # align
   
    $cmd = "korpe_gcc $l[0]_kk.pdb  --score_file ~/rcd2020/korp6Dv1.bin -o k2 > log";
    system($cmd);
     ## read log
    open(IN, "log") or die "Could not read file";
    while ($li = <IN>) {

        last if $li =~ /korpe> Energy:/;
    }

    my @f2 = split(/\s+/, $li);
    close(IN);

    
    
    print "$l[0] $f[3] $f2[2]\n";
    #print "$cmd\n";

    
    
  
}    

