import numpy as np
import MDAnalysis as mda
from MDAnalysis.analysis import align
import MDAnalysis.analysis.pca as pca
import MDAnalysis.coordinates.PDB
from MDAnalysis.analysis.rms import rmsd
from MDAnalysis.analysis.rms import RMSF
import matplotlib.pyplot as plt
import sys

filename_name = sys.argv[1]
print ("Reading ",filename_name  ) 

u = mda.Universe(filename_name)


frames=len(u.trajectory)



print ("Frames ",frames," in ",filename_name  ) 




#MDAnalysis.analysis.align.AlignTraj(u,  # trajectory to align
#                u,  # reference
#                select="backbone",  # selection of atoms to align
#                filename='aligned.xtc',  # file to write the trajectory to
#                match_atoms=True,  # whether to match atoms based on mass
#               ).run()

bb = u.select_atoms("backbone")
rmsfer = RMSF(bb).run()

plt.plot(bb.resnums, rmsfer.rmsf)

filename_name2 = sys.argv[2]
print ("writing ",filename_name2  ) 
f = open(filename_name2, "w")
x=0;
for y  in rmsfer.rmsf:
  x=x+1
  print(x,y,file=f)

f.close()

#bb = u.select_atoms("backbone")
#with MDAnalysis.Writer("calpha_traj.pdb", multiframe=True) as W:
#    for ts in u.trajectory[1::10]:
#        W.write(bb)
   


