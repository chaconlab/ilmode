#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    $cmd = "python MDbb.py  $l[0].loop.pdb  $l[0]_REMD_H1F.pdb 0 10001";
    print "$cmd\n";
    system($cmd);
    
    $cmd = "python  MDncac.py  $l[0]_REMD_H1F.pdb  $l[0]_REMD_H1.pdb 0 10001";
    print "$cmd\n";
    system($cmd);
    
    $cmd = "python MDbb.py  $l[0].loop.pdb  $l[0]_REMD_H2F.pdb 10001 20001";
    print "$cmd\n";
    system($cmd);
    
    $cmd = "python  MDncac.py  $l[0]_REMD_H2F.pdb  $l[0]_REMD_H2.pdb 0 10001";
    print "$cmd\n";
    system($cmd);
   
   
}    

