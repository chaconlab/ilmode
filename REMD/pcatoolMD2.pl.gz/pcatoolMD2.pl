#!/usr/bin/perl

open(fh, "./ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    $cmd = "pcatool $l[0]_REMD_H1.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]H1 --rmsd_log --remove_anchors  > $l[0]_MD_H1.log;\n";
    print $cmd;
    system($cmd);
    $cmd = "pcatool $l[0]_REMD_H2.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]H2 --rmsd_log --remove_anchors  > $l[0]_MD_H2.log;\n";
    print $cmd;
    system($cmd);
    

}
    
  
