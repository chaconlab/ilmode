#!/usr/bin/perl

open(fh, "rcd_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    #$rmsd=3.0*$l[6];
    $rmsd=3.0*$l[5];
    $sigma=$l[5]/10;
    $sigma=0.1;
       
    $cmd = "echo \"$l[0]_refPDB.pdb $l[1] $l[2] $l[3]\" > tmp";
    system($cmd);
    

    $cmd = "~/git/sbg/bin/rcd tmp -n 50000 -r -t 0.90 -d 0.3 --linear -m 1  -x ~/rcd2020/dunbrack.bin --energy_file ~/rcd2020/korp6Dv1.bin -o rcd5 -s 1 -c 0 --bench; grep $l[0] rcd5/results.txt; cp rcd5/results.txt rcd5/results_$l[0].txt";
    print "$cmd\n";


    system($cmd);
  
}    

