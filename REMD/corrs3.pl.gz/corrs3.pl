#!/usr/bin/perl

use File::Basename;


unless(@ARGV == 7)
{
    printf( "USAGE: $0\n\tXmatrix Ymatrix Xcol Ycol irow frow(all) MADcutoff\n" );
    printf( "\n\tAdvice: Only Y-data will be fitted to X-data\n" );
    printf( "\t(PDB name taken from Xmatrix basename.)\n\n" );
    exit(0);
}
$debug = 0;
$xcol = $ARGV[2];
$ycol = $ARGV[3];
$irow = $ARGV[4] - 1;
$frow = $ARGV[5];
if ($frow ne 'all') { $frow = $ARGV[5] - 1; }
$cutoff = $ARGV[6];
my $pdb=substr(basename($ARGV[0]),0,4); # Gets the pdb name from the first .evec file!

#
# Use as is - no guarantees :-)
#--------------------------------------------------------------
#@columns = ($xcol,$ycol);
@columns = (1,2); # To avoid deep changes to old rank correlation code
#--------------------------------------------------------------
# Read data.
# $line_number is the current line number; $column the current column.
# %score will hold the value for any combination of key and column.
# %individuals will hold a "1" for every line with a non-null value. If a line
# holds some nulls but at least one non-null value the nulls will be interpreted
# as zero values.
$line_number = 0;
my (@x,@y);
open (XFILE,"$ARGV[0]");

while (<XFILE>) 
{
    
    @_=split(/\s+/, $_);
    if ($frow ne 'all') # then, only reads between $irow and $frow
    { 
    if( $line_number >= $irow && $line_number <= $frow ) # Whether we're reading inside the row limits specified
	    {
		$individuals{$line_number} = 1;
		if( $_[$xcol] ne "" ) 
		{ 
			push(@x,$_[$xcol]);
			$score{1,$line_number} = $_[$xcol];
		} 
		else 
		{ print "Null elements in matrix\n"; exit(1); }
	    }
    }
    else # then, reads every row from $irow
    { 
    if( $line_number >= $irow ) 
	    {
		$individuals{$line_number} = 1;
		if( $_[$xcol] ne "" ) 
		{ 
			push(@x,$_[$xcol]); 
			$score{1,$line_number} = $_[$xcol];
		} 
		else 
		{ print "Null elements in matrix\n"; exit(1); }
	    }
    }
    $line_number++;
};
close XFILE;

my $line_numX = $line_number; # to check...
$line_number = 0;

open (YFILE,"$ARGV[1]");
while (<YFILE>) {
    @_=split(/\s+/, $_);
    if ($frow ne 'all') # then, only reads between $irow and $frow
    { 
    if( $line_number >= $irow && $line_number <= $frow ) # Whether we're reading inside the row limits specified
	    {
		$individuals{$line_number} = 1;
		if( $_[$ycol] ne "" ) 
		{ 
			push(@y,$_[$ycol]);
			$score{2,$line_number} = $_[$ycol];
		} 
		else 
		{ print "Null elements in matrix\n"; exit(1); }
	    }
    }
    else # then, reads every row from $irow
    { 
    if( $line_number >= $irow ) 
	    {
		$individuals{$line_number} = 1;
		if( $_[$ycol] ne "" ) 
		{ 
			push(@y,$_[$ycol]); 
			$score{2,$line_number} = $_[$ycol];
		} 
		else 
		{ print "Null elements in matrix\n"; exit(1); }
	    }
    }
    $line_number++;
};
close YFILE;
my $line_numY = $line_number;  # to check...

# some checking...
if ($line_numX != $line_numY)
{
	print "Different number of lines found!\tForcing exit!!!\n\n";
	exit;
}

if ($frow eq 'all') { $frow = $line_number - 1; }

if ($debug) { print "Input Data X:\n@x\nInput Data Y:\n@y\n"; }









my ($corr_all,$corr_rank);
my ($avgX,$sigX,$avgY,$sigY);
($corr_all,$avgX,$sigX,$avgY,$sigY) = corr(\@x,\@y);
$corr_rank = rank();

my @normX = norm(\@x);
my @normY = norm(\@y);
my ($corr_allN,$corr_rankN);
my ($avgXN,$sigXN,$avgYN,$sigYN);
($corr_allN,$avgXN,$sigXN,$avgYN,$sigYN) = corr(\@normX,\@normY);



my @fit = fitxtoy(\@y,\@x);
$avg_fit = average(@fit);
$sig_fit = sigma(@fit);



printf( "%10s %5s %5s %10s %10s\n","#Head:    ","PDB","N","Corr","Rank_all");
printf( "%10s %5s %5d %10.5f %10.5f\n"  ,"#Cros:    ",$pdb,$#x,$corr_all,$corr_rank);
printf( "%5s %10s %10s %10s %10s %10s\n","#Head:","X_Data","Y_Data","Fit_YtoX","Norm_X","Norm_Y");

my ($i,$cont_ok);
foreach(@x)
{
        # Shows the normalized X & Y data profiles.
	printf( "%6d %10.5f %10.5f %10.5f %10.5f %10.5f\n",$i+1,$x[$i],$y[$i],$fit[$i],$normX[$i],$normY[$i] );	
	$i++;
}


printf( "%6s %10.5f %10.5f %10.5f %10.5f %10.5f\n","#Avgs:",
	$avgX, $avgY,
	$avg_fit, $avgXN, $avgXN);
	
printf( "%6s %10.5f %10.5f %10.5f %10.5f %10.5f\n","#Sigs:",
	$sigX, $sigY, $sig_fit,$sigXN, $sigXN);



exit(0);

	
# SUB RUTINES...............................................................................

# A median-based method for Outlier detection. From: Pandini et al. 2007 PEDS.
# Returns 4 arrays (by reference) with the good values, good indexes, bad values and bad indexes,
# respectively.
#
sub outlier
{
	my ($dat,$cutoff) = @_;
	if($debug) { print "@$dat\n$cutoff\n"; }
	my (@ok,@ok_index,@out,@out_index);
	my $index=0;
	my ($mi,$outliers);
	my $med = median(@$dat);

	if($debug) { print "median: $med\n"; }
	my @mad;
	foreach (@$dat)
	{
		push(@mad, abs(@$dat[$index]-$med) );
		$index++;
	}
	my $MAD = median(@mad); # median of absolute displacements (MAD)
	
#	print "@$dat\n$cutoff\n";
	if( $MAD == 0 )
	{
		print "Median of Absolute Displacements is zero!\nImpossible to continue!\nBAD DATA INPUT!\n\n";
		print "Forcing exit and avoiding: Illegal division by zero\n";
		exit;
	}
	
	if($debug) { print "MAD: $MAD\n"; }
	$index=0;
	foreach (@$dat)
	{
		$mi = abs(0.6745*(@$dat[$index]-$med)/$MAD) ;
		if($debug) { printf( "%5d %10.5f %10.5f",$index+1,@$dat[$index],$mi ); }
		if( $mi <= $cutoff) 
		{ 
			push(@ok,@$dat[$index]); # storing valid data
			push(@ok_index,$index); # storing valid data indexes
		}
		else 
		{
			push(@out,@$dat[$index]); # storing discarded data
			push(@out_index,$index); # storing discarded data indexes
			$outliers++; 
			if($debug) { printf( " (Discarded)"); }
		}
		if($debug) { printf( "\n"); }
		$index++;
	}
	return \(@ok,@ok_index,@out,@out_index);
}

sub median
{
	@array = @_;
	my @sorted = sort {$a <=> $b } @array;
	$n = $#sorted + 1;
	
#	print "median (array): @array\n";
#	print "median (sorted): @sorted\n";
	
	if( $n%2 == 0) { return( ($sorted[$n/2 - 1] + $sorted[$n/2])/2 ); }
	else { return( $sorted[($n+1)/2 - 1] ); }

}

sub average
{
	@data = @_;
        my $avg;
	my $n = $#data + 1;
	$avg=0;
	foreach(@data)
	{ $avg += $_; }
        $avg /= $n;
	return($avg);
}

sub sigma
{
	@data = @_;
	my $n = $#data + 1;
	my $avg = average(@data);
	my $sig;
	$sig=0;
	foreach(@data)
	{ $sig += ($_ - $avg)**2; }
	$sig /= $n;
	$sig = sqrt($sig);
	return($sig);

}

sub corr
{
	($dataX,$dataY) = @_;
	my ($avgX,$avgY,$sigX,$sigY,$corr);
	$avgX = average(@$dataX);
	$avgY = average(@$dataY);
	$sigX = sigma(@$dataX);
	$sigY = sigma(@$dataY);

	my $index;
	$corr=0;
	foreach(@$dataX)
	{
		$corr += (@$dataX[$index] - $avgX) * (@$dataY[$index] - $avgY);
		$index++;
	}
	$corr /= $index;
	$corr = $corr / ($sigX * $sigY);
	return ($corr,$avgX,$sigX,$avgY,$sigY);

}


# Normalizes an array to average=0 and sigma=1;
sub norm
{
	my $data = shift;
	my @out;
	$avg = average(@$data);
	$sig = sigma(@$data);

	my $index;
	foreach(@$data)
	{
		$out[$index] = ($_ - $avg) / $sig; 
		$index++;
	}
	
	return( @out );
}

sub fitxtoy
{
	($dataX,$dataY) = @_;
	my ($avgX,$avgY,$sigX,$sigY,$corr);
	$avgX = average(@$dataX);
	$avgY = average(@$dataY);
	$sigX = sigma(@$dataX);
	$sigY = sigma(@$dataY);

	my $index;
	my @fitX;
	foreach(@$dataX)
	{
		$fitX[$index] = $avgY + $sigY * (@$dataX[$index] - $avgX) / $sigX ;
		$index++;
	}
	return( @fitX );
}

sub fitxtoyallx
{
	($dataX,$dataY,$allX) = @_;
	my ($avgX,$avgY,$sigX,$sigY,$corr);
	$avgX = average(@$dataX);
	$avgY = average(@$dataY);
	$sigX = sigma(@$dataX);
	$sigY = sigma(@$dataY);

	my $index;
	my @fitX;
	foreach(@$allX)
	{
		$fitX[$index] = $avgY + $sigY * (@$allX[$index] - $avgX) / $sigX ;
		$index++;
	}
	return( @fitX );
}

sub rank
{
# backward way of seeing how many individuals had values.
@tmp_n = keys %individuals;
$n = $#tmp_n + 1;
if($debug) { print "How many individuals: $n\n"; }


foreach $column (@columns) {
    $this_rank = 0;
    # $individual will in turn contain the index of a cell to be studied in $column.
    # each cycle, it will be put in $previous_index and the cell contents in $previous_score
    foreach $individual (sort {$score{$column,$a} <=> $score{$column,$b}} keys %individuals) {
        # Are the values equal? 
        # YES: Stack the individual in @stack of $duplicates and wait for a new value to show up.
        #      Well, except if we are at the first element, of course. 
	if ($this_rank > 0 && $score{$column,$individual} == $score{$column,$previous}) {
	    print STDERR "$column $individual	->	st	$score{$column,$individual} $score{$column,$previous}  d $duplicates EQ!\n" if $debug;
	    $stack[$duplicates] = $previous;
	    $duplicates++;
        # Are the values equal? 
	# NO: Pop the stack, and put the previous item into %rank.
	} else {
            # unroll the stack if necessary
	    if ($duplicates) { 
		$stack[$duplicates] = $previous;
		$duplicates++;
		# then calculate the average for the stack. 
		$rank_average = $this_rank - 1 - $#stack/2;
		# foreach stacked duplicate value, put in the average rank.
		$d = $duplicates;
		foreach $double (@stack) {
		    print STDERR "$column $double	->	$rank_average	$score{$column,$double} UNSTACK\n" if $debug;
		    $rank{$column,$double} = $rank_average;
		};
		# empty the stack.
		$duplicates = 0;
		@stack = ();
	    } else {
		# if no stack, put the previous rank into %rank
		print STDERR "$column $previous	->	$previous_rank	$score{$column,$previous} INPUT!\n" if $debug;
		$rank{$column,$previous} = $previous_rank;
	    };
	};
	# Put the current position and rank into memory for next iteration.
	$previous = $individual;
	$previous_rank = $this_rank;
	$this_rank++;	
    };
    
    # after the last element, are there any left on stack? (was the last element a duplicate?)
    if ($duplicates) {
	$stack[$duplicates] = $previous;
	$duplicates++;
	# then calculate the average for the stack. 
	$rank_average = $this_rank - 1 - $#stack/2;
	# foreach stacked duplicate value, put in the average rank.
	$d = $duplicates;
	foreach $double (@stack) {
	    print STDERR "$column $double	->	$rank_average	$score{$column,$double} UNSTACK\n" if $debug;
	    $rank{$column,$double} = $rank_average;
	};
	# empty the stack.
	$duplicates = 0;
	@stack = ();
    } else {
	# if no stack, put the previous rank into %rank
	print STDERR "$column $previous	->	$previous_rank	$score{$column,$previous} INPUT!\n" if $debug;
	$rank{$column,$previous} = $previous_rank;
    };
};
if ($debug) { 
    foreach $individual (sort {$a <=> $b} keys %individuals) {
	print "$individual	";
	foreach $column (@columns) {
	    print ">$rank{$column,$individual}:$score{$column,$individual}<	";
	};
	print "\n";
    }
}
%score = ();

$D2 = 0;
foreach $line (keys %individuals) 
{
$D2 += ($rank{$columns[0],$line}-$rank{$columns[1],$line})*($rank{$columns[0],$line}-$rank{$columns[1],$line});
# It Sums the Squared difference of ranks. Formula (14.6.3) from "Numerical Recipes"
};
$rs = 1-6*$D2/($n*($n*$n-1)); # $n --> number of "individuals"
			      # Formula (14.6.4) from "Numerical REcipes"
#printf "%6.5f", $rs;
return( $rs );

}
