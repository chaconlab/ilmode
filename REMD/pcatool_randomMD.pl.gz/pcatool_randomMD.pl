#!/usr/bin/perl

for(my $i = 4; $i < 11; $i++){

open(fh, "ilmode_in.txt") or die "Could not read file";
while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    $cmd = "pcatool $l[0]_REMD_H2.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]H2 --rmsd_log --remove_anchors --random_model > $l[0]_MD_H2.log;\n";

    print $cmd;
    system($cmd);    
  
}    
close(fh);

$cmd = "compareMD.pl; table0MD.pl > randomMD_$i.txt\n";
print $cmd;
system($cmd);    

}
