#!/usr/bin/perl

open(fh, "ilmode_in_rcd.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    
    $cmd = "selectFrame.pl  rcd/$l[0]_refPDB_closed.pdb   $l[8] >  $l[0]_rcdB_loop.pdb\n";
    print "$cmd\n";
    system($cmd);
    $cmd = "../insertpdb.pl $l[0]_rcdB_loop.pdb  $l[0]_refPDB.pdb  $l[0]_rcdB.pdb noanchors\n";    
    print "$cmd\n";
    system($cmd);

 
    $rmsd=$l[7];
    $rmsd=3.0;
    $sigma=0.1;


    $cmd = "ilmode $l[0]_rcdB.pdb $l[1] $l[2] --chain \"A\" -o \"\" -m 3 -s 2 -a 2 --rmsd $rmsd --k0_k 1.0 --k0_c 10 --drmsd $sigma --nr 1000 --skip_missingatoms >  $l[0]_rcdB.log ";
    print "$cmd\n";
    system($cmd);
  
}    

