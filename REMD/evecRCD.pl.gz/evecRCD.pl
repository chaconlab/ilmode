#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    
    open(OUT, ">$l[0]_rcd.pdb") or die "Could not read file";

    
    open(IN, "$l[0]_refNCAC.pdb") or die "Could not read file";
    printf OUT "MODEL        1\n";
    while ($li = <IN>) {
    last if $li =~ s/TER//;
            printf OUT $li;
    }
    printf OUT "ENDMDL\n";
    close(IN);
    

    open(IN, "rcd/$l[0]_refPDB_closed.pdb") or die "Could not read file $l[0]_closed.pdb";
    while ($li = <IN>) {
    last if $li =~ s/ENDMDL//;
    }
    while ($li = <IN>) {
    printf OUT $li;
    }
    close(IN);
    close(OUT);

    
  
}    

