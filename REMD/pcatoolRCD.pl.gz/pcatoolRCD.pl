#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
   # $cmd = "pcatool $l[0]_rcd.pdb  --nalign 1  -n 0.99  --pca -m 3 -o $l[0]_rcd --rmsd_log  --remove_anchors > $l[0]_rcd.log;\n";
    $cmd = "pcatool $l[0]_rcd.pdb  --nalign 1  -n 0.99  --pca -m 3 -o $l[0]_rcd --rmsd_log   > $l[0]_rcd.log;\n";
    print $cmd;
    system($cmd);

    
  
}    

