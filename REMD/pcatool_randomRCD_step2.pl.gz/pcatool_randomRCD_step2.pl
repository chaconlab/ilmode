#!/usr/bin/perl

open(fh, "./ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    $cmd = "grep $l[0] randomRCD_*.txt > kk; ../statext.pl kk 1 18 1 all 1 > kk2 \n";
    
    #print $cmd;
    system($cmd);
    
    open(IN, "kk2") or die "Could not read file";
    my @bf=();
      while ($li = <IN>) {
    last if $li =~ s/#Avg//;
    }
    my @f = split(/\s+/, $li );
    $li = <IN>;
    my @f2 = split(/\s+/, $li );
    close(IN);
    printf ("%4s %6.3f %6.3f %6.3f %6.3f %6.3f %6.3f %6.3f %6.3f\n", $l[0], $f[6], $f2[6], $f[10], $f2[10], $f[14], $f2[14], $f[17], $f2[17]);  
  
}    
close(fh);


