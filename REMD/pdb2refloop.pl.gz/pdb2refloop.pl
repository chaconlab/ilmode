#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    
    # get full atom loop
    open(IN, "$l[0]_MD_H2.log") or die "Could not read file";
    while ($li = <IN>) {
    last if $li =~ s/-th structure as reference//;
    }
    my @f = split(/\s+/, $li); 
    close(IN); 
    print "Structure ref $f[3]\n";
    
    $cmd = "selectFrame.pl  $l[0]_REMD_H2F.pdb  $f[3] > temp; pdb_chain -A temp > $l[0]_ref_full.pdb\n";
    print "$cmd\n";
    system($cmd);
    
    $cmd = "selectFrame.pl  $l[0]_REMD_H2.pdb  $f[3] > temp; pdb_chain -A temp > $l[0]_ref2.pdb\n";
    print "$cmd\n";
    system($cmd);
    
    
    
    # align
    $cmd = "rmsd  $l[0]_ref_full.pdb  ../alignPDBs/$l[0]300.pdb --start $l[1] --end $l[2] --flanks 1 -o $l[0]_alnPDB.pdb --noH\n";
    #print "$cmd\n";
    #system($cmd);
    #$cmd = "grep \" N \\| CA \\| C \" $l[0]_ref_full.pdb  >  $l[0]_refNCAC.pdb ";
    #system($cmd);
    
    #insert loop
    $cmd = "../insertpdb.pl  $l[0]_ref_full.pdb  ../alignPDBs/$l[0]300.pdb  $l[0]_refPDB.pdb noanchors\n"; 
    $cmd = "../insertpdb.pl  $l[0]_ref_full.pdb   $l[0]_alnPDB.pdb   $l[0]_refPDB.pdb \n"; 
    #$cmd = "../insertpdb.pl $l[0]_ref_full.pdb  ../alignPDBs/$l[0]300.pdb  $l[0]_refPDB.pdb noanchors\n"; 
    #$cmd = "cp ../alignPDBs/pdbsA/$l[0]C.pdb  $l[0]_refPDB.pdb; cp ../alignPDBs/pdbsA/$l[0]C_loopA.pdb  $l[0]_ref_full.pdb; cp ../alignPDBs/pdbsA/$l[0]C_loopANCAC.pdb  $l[0]_ref2.pdb; \n"; 
   
    
    print "$cmd\n";
    system($cmd);
    
  
}    

