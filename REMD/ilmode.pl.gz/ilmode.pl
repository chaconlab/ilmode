#!/usr/bin/perl

open(fh, "ilmode_in.txt") or die "Could not read file";

while($line = <fh>) {
    chomp;
    @l = split(' ', $line);
    $rmsd=2*$l[5];
    if ($rmsd<1.5) {$rmsd=1.5;}
    $rmsd=$l[7];
    $sigma=$l[5]/10;
    $sigma=0.1;

    $cmd = "ilmode $l[0]_ref.pdb $l[1] $l[2] --chain \"A\" -o \"\" -m 3 -s 2 -a 2 --rmsd $rmsd   --drmsd 0.1 --nr 500 --skip_missingatoms --nloops 10000>  $l[0]_ref.log ";
    $cmd = "ilmode $l[0]_refPDB.pdb $l[1] $l[2] --chain \"A\" -o \"\" -m 3 -s 2 --rmsd $rmsd --drmsd $sigma --nr 500 --skip_missingatoms --nloops 10000 >  $l[0]_ref.log;";
    print "$cmd\n";
   # system($cmd);
  
}    



