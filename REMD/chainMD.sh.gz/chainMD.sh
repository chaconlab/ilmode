########################################################
# add chain
########################################################

 # Get pdbs list for current case

pdbs=`ls ????_REMD_H??.pdb`

for a in $pdbs
 do
  echo -e "PDB --> $a"
  pdb_chain -A $a > temp
  mv temp $a
 done


