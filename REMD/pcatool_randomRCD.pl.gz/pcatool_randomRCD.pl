#!/usr/bin/perl

for(my $i = 0; $i < 10; $i++){

open(fh, "ilmode_in.txt") or die "Could not read file";
while($line = <fh>) {
    chomp;
    @l = split(' ', $line);

   # $cmd = "pcatool $l[0]_rcd.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]_rcd  --rmsd_log --remove_anchors --random_model > $l[0]_rcd.log; \n";  
     $cmd = "pcatool $l[0]_rcd.pdb  --nalign -1  -n 0.99  --pca -m 3 -o $l[0]_rcd  --rmsd_log --random_model > $l[0]_rcd.log; \n";


    print $cmd;
    system($cmd);    
  
}    
close(fh);

$cmd = "compareRCD.pl; table0RCD.pl > randomRCD_$i.txt\n";
print $cmd;
system($cmd);    

}
