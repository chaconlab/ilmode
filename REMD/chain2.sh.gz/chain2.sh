########################################################
# add chain
########################################################

 # Get pdbs list for current case
pdbs=`ls ????_ref2.pdb`

 # Morphing all PDBs against each other (all-against-all)
for a in $pdbs
 do
  name=${a:0:8}.pdb
  echo -e "PDB --> $a"
  pdb_chain -A $a > temp
  mv temp $name
 done





