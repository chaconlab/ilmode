import numpy as np
import MDAnalysis as mda
from MDAnalysis.analysis import align
import MDAnalysis.analysis.pca as pca
import MDAnalysis.coordinates.PDB
from MDAnalysis.analysis.rms import rmsd
from MDAnalysis.analysis.rms import RMSF
import matplotlib.pyplot as plt
import sys

filename_name = sys.argv[1]
filename_name2 = sys.argv[2]
start  = int (sys.argv[3])
end = int (sys.argv[4])

print ("Reading ",filename_name  ) 

u = mda.Universe(filename_name)


frames=len(u.trajectory)



print ("Frames ",frames," in ",filename_name  ) 




print ("Saving NCAC traj",filename_name2, " from ", start, "to", end  ) 

bb = u.select_atoms("name CA or name C or name N")
#bb = u.select_atoms("backbone")
with MDAnalysis.Writer(filename_name2, multiframe=True) as W:
    for ts in u.trajectory[start:end]:
        W.write(bb)
   


